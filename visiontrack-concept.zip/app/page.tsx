"use client"

import { Navbar } from "@/components/navbar"
import { Hero } from "@/components/hero"
import { AnalyzerApp } from "@/components/analyzer-app"
import { Footer } from "@/components/footer"

export default function Home() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950">
      <Navbar />
      <Hero />
      <AnalyzerApp />
      <Footer />
    </main>
  )
}
