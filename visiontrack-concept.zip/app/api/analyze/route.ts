import { z } from "zod"

const analysisSchema = z.object({
  deviations: z.array(z.string()).describe("List of detected visual deviations"),
  confidence: z.number().min(0).max(1).describe("Overall confidence score"),
  severity: z.enum(["low", "medium", "high"]).describe("Severity level of deviations"),
  details: z.string().describe("Detailed analysis summary"),
  anomalies: z.array(
    z.object({
      type: z.string().describe("Type of anomaly"),
      location: z.string().describe("Location in image"),
      confidence: z.number().min(0).max(1),
    }),
  ),
})

// Mock analysis data generator
function generateMockAnalysis() {
  const deviationOptions = [
    "Color shift detected in upper-left quadrant",
    "Slight blur detected in center region",
    "Lighting inconsistency on right edge",
    "Texture irregularity in background",
    "Saturation variance detected",
    "Edge distortion in lower section",
    "Contrast anomaly identified",
    "Pixel noise detected in shadows",
  ]

  const anomalyTypes = [
    "Color Deviation",
    "Blur Detection",
    "Lighting Anomaly",
    "Texture Irregularity",
    "Saturation Shift",
    "Edge Distortion",
    "Contrast Issue",
    "Noise Pattern",
  ]

  const locations = [
    "Top-left corner",
    "Center region",
    "Right edge",
    "Bottom section",
    "Upper-right area",
    "Lower-left corner",
    "Center-left area",
    "Top-right quadrant",
  ]

  // Randomly decide severity
  const severityRandom = Math.random()
  let severity: "low" | "medium" | "high"
  if (severityRandom < 0.4) severity = "low"
  else if (severityRandom < 0.75) severity = "medium"
  else severity = "high"

  // Generate 1-3 deviations
  const deviationCount = Math.floor(Math.random() * 3) + 1
  const deviations = []
  for (let i = 0; i < deviationCount; i++) {
    deviations.push(deviationOptions[Math.floor(Math.random() * deviationOptions.length)])
  }

  // Generate 1-3 anomalies
  const anomalyCount = Math.floor(Math.random() * 3) + 1
  const anomalies = []
  for (let i = 0; i < anomalyCount; i++) {
    anomalies.push({
      type: anomalyTypes[Math.floor(Math.random() * anomalyTypes.length)],
      location: locations[Math.floor(Math.random() * locations.length)],
      confidence: Math.random() * 0.4 + 0.6, // 60-100%
    })
  }

  const confidenceScore = Math.random() * 0.3 + 0.7 // 70-100%

  const detailsOptions = [
    "Analysis complete. The image shows typical variations in lighting and color distribution. No critical issues detected.",
    "Scan finished. Minor visual inconsistencies detected but within acceptable parameters for standard images.",
    "Processing complete. Image quality is good with some minor anomalies in the peripheral regions.",
    "Analysis done. Detected some texture variations that are common in natural images.",
    "Scan complete. The image exhibits normal color and lighting variations with no major deviations.",
  ]

  return {
    deviations,
    confidence: confidenceScore,
    severity,
    details: detailsOptions[Math.floor(Math.random() * detailsOptions.length)],
    anomalies,
  }
}

export async function POST(request: Request) {
  try {
    const { image } = await request.json()

    if (!image) {
      return Response.json({ error: "No image provided" }, { status: 400 })
    }

    // Simulate processing delay
    await new Promise((resolve) => setTimeout(resolve, 1500))

    // Generate mock analysis
    const mockAnalysis = generateMockAnalysis()

    return Response.json(mockAnalysis)
  } catch (error) {
    console.error("[v0] Analysis error:", error)
    return Response.json({ error: "Analysis failed" }, { status: 500 })
  }
}
