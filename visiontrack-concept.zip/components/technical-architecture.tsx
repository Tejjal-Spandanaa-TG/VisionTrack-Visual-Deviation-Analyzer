"use client"

import { Card } from "@/components/ui/card"
import { Brain, Cloud, Smartphone, Database } from "lucide-react"

export function TechnicalArchitecture() {
  const components = [
    {
      icon: Smartphone,
      title: "Edge Capture",
      description: "Drone/IoT cameras capture high-resolution images with metadata (GPS, timestamp, device ID)",
      color: "text-blue-400",
    },
    {
      icon: Cloud,
      title: "Cloud Pipeline",
      description: "Serverless functions auto-trigger on image upload for preprocessing and normalization",
      color: "text-cyan-400",
    },
    {
      icon: Brain,
      title: "AI Engine",
      description: "Siamese CNN networks compare image pairs, generate heatmaps, and classify change types",
      color: "text-purple-400",
    },
    {
      icon: Database,
      title: "Data Layer",
      description: "Time-series database stores results, enabling trend analysis and historical comparisons",
      color: "text-green-400",
    },
  ]

  return (
    <section className="py-20 px-4 bg-slate-950">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-4xl font-bold text-white mb-4 text-center">Technical Architecture</h2>
        <p className="text-slate-400 text-center mb-16 max-w-2xl mx-auto">
          A modular, scalable system combining computer vision, cloud automation, and explainable AI
        </p>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {components.map((comp, idx) => {
            const Icon = comp.icon
            return (
              <Card key={idx} className="bg-slate-800 border-slate-700 p-6 hover:border-slate-600 transition">
                <Icon className={`w-8 h-8 ${comp.color} mb-4`} />
                <h3 className="text-lg font-bold text-white mb-2">{comp.title}</h3>
                <p className="text-sm text-slate-400">{comp.description}</p>
              </Card>
            )
          })}
        </div>

        {/* Tech Stack */}
        <Card className="bg-gradient-to-r from-slate-800 to-slate-700 border-slate-600 p-8">
          <h3 className="text-xl font-bold text-white mb-6">Technology Stack</h3>
          <div className="grid md:grid-cols-3 gap-8">
            <div>
              <h4 className="text-blue-400 font-semibold mb-3">AI/ML</h4>
              <ul className="text-sm text-slate-300 space-y-2">
                <li>• PyTorch / TensorFlow</li>
                <li>• Siamese Networks</li>
                <li>• Grad-CAM Attention Maps</li>
                <li>• ONNX Runtime (inference)</li>
              </ul>
            </div>
            <div>
              <h4 className="text-cyan-400 font-semibold mb-3">Cloud & Backend</h4>
              <ul className="text-sm text-slate-300 space-y-2">
                <li>• AWS Lambda / Google Cloud Functions</li>
                <li>• S3 / Cloud Storage</li>
                <li>• TimescaleDB / InfluxDB</li>
                <li>• WebSocket for real-time updates</li>
              </ul>
            </div>
            <div>
              <h4 className="text-purple-400 font-semibold mb-3">Frontend & AR</h4>
              <ul className="text-sm text-slate-300 space-y-2">
                <li>• React / Next.js</li>
                <li>• Three.js / Babylon.js (AR)</li>
                <li>• WebGL for heatmap rendering</li>
                <li>• ARKit / ARCore integration</li>
              </ul>
            </div>
          </div>
        </Card>
      </div>
    </section>
  )
}
