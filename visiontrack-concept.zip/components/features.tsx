"use client"

import { CheckCircle2, Zap, Shield, BarChart3, Cpu, Cloud } from "lucide-react"

export function Features() {
  const features = [
    {
      icon: Cpu,
      title: "CNN-Powered Detection",
      description:
        "State-of-the-art convolutional neural networks trained on 100K+ industrial images for unmatched accuracy",
    },
    {
      icon: Zap,
      title: "Lightning Fast",
      description: "Process entire image sequences in seconds with optimized inference pipelines and GPU acceleration",
    },
    {
      icon: Shield,
      title: "Enterprise Security",
      description: "End-to-end encryption, SOC 2 compliance, and on-premise deployment options for sensitive data",
    },
    {
      icon: BarChart3,
      title: "Advanced Analytics",
      description: "Comprehensive dashboards with trend analysis, anomaly detection, and predictive insights",
    },
    {
      icon: Cloud,
      title: "Cloud Native",
      description: "Seamless integration with AWS, Azure, and GCP. Auto-scaling for variable workloads",
    },
    {
      icon: CheckCircle2,
      title: "Easy Integration",
      description: "RESTful APIs, webhooks, and SDKs for Python, Node.js, and Go. Deploy in minutes",
    },
  ]

  return (
    <section id="features" className="py-20 px-4 bg-slate-950">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">Powerful Features</h2>
          <p className="text-lg text-slate-300 max-w-2xl mx-auto">
            Everything you need to detect, analyze, and act on visual changes at scale
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => {
            const Icon = feature.icon
            return (
              <div
                key={index}
                className="bg-slate-900/50 border border-slate-800 rounded-lg p-6 hover:border-blue-500/50 transition-colors group"
              >
                <div className="mb-4 inline-block p-3 bg-blue-500/10 rounded-lg group-hover:bg-blue-500/20 transition-colors">
                  <Icon className="w-6 h-6 text-blue-400" />
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">{feature.title}</h3>
                <p className="text-sm text-slate-400">{feature.description}</p>
              </div>
            )
          })}
        </div>

        <div className="mt-16 bg-gradient-to-r from-blue-900/20 to-cyan-900/20 border border-blue-500/20 rounded-lg p-8 text-center">
          <h3 className="text-2xl font-bold text-white mb-4">Ready to Transform Your Operations?</h3>
          <p className="text-slate-300 mb-6 max-w-2xl mx-auto">
            Join leading manufacturers and infrastructure companies using VisionTrack to reduce defects, improve
            quality, and accelerate inspections.
          </p>
          <button className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 rounded-lg font-semibold transition-colors">
            Start Free Trial
          </button>
        </div>
      </div>
    </section>
  )
}
