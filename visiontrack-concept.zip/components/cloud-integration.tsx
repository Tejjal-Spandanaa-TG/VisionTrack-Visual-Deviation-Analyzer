"use client"

import { Cloud, Database, Zap, Shield } from "lucide-react"

export function CloudIntegration() {
  const integrations = [
    { name: "AWS", icon: "☁️", color: "from-orange-500 to-yellow-500" },
    { name: "Azure", icon: "🔷", color: "from-blue-500 to-cyan-500" },
    { name: "GCP", icon: "🌐", color: "from-red-500 to-yellow-500" },
    { name: "On-Premise", icon: "🏢", color: "from-slate-500 to-slate-600" },
  ]

  return (
    <section className="py-20 px-4 bg-slate-950">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">Cloud-Native Architecture</h2>
          <p className="text-lg text-slate-300 max-w-2xl mx-auto">
            Deploy anywhere. Scale infinitely. Integrate seamlessly with your existing infrastructure.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-12 items-center mb-16">
          <div className="bg-slate-900/50 border border-slate-800 rounded-lg p-8">
            <h3 className="text-2xl font-bold text-white mb-6">Deployment Options</h3>
            <div className="grid grid-cols-2 gap-4">
              {integrations.map((integration, index) => (
                <div
                  key={index}
                  className="bg-slate-800/50 border border-slate-700 rounded-lg p-4 text-center hover:border-blue-500/50 transition-colors"
                >
                  <div className="text-3xl mb-2">{integration.icon}</div>
                  <p className="text-white font-semibold text-sm">{integration.name}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-6">
            <div className="flex gap-4">
              <div className="flex-shrink-0">
                <div className="flex items-center justify-center h-12 w-12 rounded-lg bg-blue-500/20">
                  <Cloud className="h-6 w-6 text-blue-400" />
                </div>
              </div>
              <div>
                <h4 className="text-white font-semibold mb-1">Auto-Scaling</h4>
                <p className="text-slate-400 text-sm">Automatically scale compute resources based on demand</p>
              </div>
            </div>

            <div className="flex gap-4">
              <div className="flex-shrink-0">
                <div className="flex items-center justify-center h-12 w-12 rounded-lg bg-cyan-500/20">
                  <Database className="h-6 w-6 text-cyan-400" />
                </div>
              </div>
              <div>
                <h4 className="text-white font-semibold mb-1">Data Management</h4>
                <p className="text-slate-400 text-sm">Secure storage with automatic backups and disaster recovery</p>
              </div>
            </div>

            <div className="flex gap-4">
              <div className="flex-shrink-0">
                <div className="flex items-center justify-center h-12 w-12 rounded-lg bg-purple-500/20">
                  <Zap className="h-6 w-6 text-purple-400" />
                </div>
              </div>
              <div>
                <h4 className="text-white font-semibold mb-1">Performance</h4>
                <p className="text-slate-400 text-sm">Global CDN with sub-100ms latency for real-time processing</p>
              </div>
            </div>

            <div className="flex gap-4">
              <div className="flex-shrink-0">
                <div className="flex items-center justify-center h-12 w-12 rounded-lg bg-green-500/20">
                  <Shield className="h-6 w-6 text-green-400" />
                </div>
              </div>
              <div>
                <h4 className="text-white font-semibold mb-1">Security</h4>
                <p className="text-slate-400 text-sm">End-to-end encryption, compliance certifications, audit logs</p>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-r from-slate-900 to-slate-800 border border-slate-700 rounded-lg p-8">
          <div className="grid md:grid-cols-3 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold text-blue-400 mb-2">99.99%</div>
              <p className="text-slate-300">Uptime SLA</p>
            </div>
            <div>
              <div className="text-4xl font-bold text-cyan-400 mb-2">&lt;100ms</div>
              <p className="text-slate-300">Global Latency</p>
            </div>
            <div>
              <div className="text-4xl font-bold text-purple-400 mb-2">∞</div>
              <p className="text-slate-300">Horizontal Scaling</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
