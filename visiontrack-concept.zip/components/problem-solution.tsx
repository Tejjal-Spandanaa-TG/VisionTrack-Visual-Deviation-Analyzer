"use client"

import { AlertCircle, CheckCircle2 } from "lucide-react"
import { Card } from "@/components/ui/card"

export function ProblemSolution() {
  return (
    <section className="py-20 px-4 bg-slate-900">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-4xl font-bold text-white mb-16 text-center">Problem → Solution</h2>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Problem */}
          <Card className="bg-slate-800 border-slate-700 p-8">
            <div className="flex items-start gap-4 mb-6">
              <AlertCircle className="w-8 h-8 text-red-400 flex-shrink-0 mt-1" />
              <h3 className="text-2xl font-bold text-white">The Problem</h3>
            </div>

            <ul className="space-y-4 text-slate-300">
              <li className="flex gap-3">
                <span className="text-red-400 font-bold">•</span>
                <span>
                  <strong>Manual Inspection Bottleneck:</strong> Visual inspections are time-consuming, subjective, and
                  prone to human error
                </span>
              </li>
              <li className="flex gap-3">
                <span className="text-red-400 font-bold">•</span>
                <span>
                  <strong>Scale Challenges:</strong> Monitoring thousands of assets across distributed locations is
                  operationally expensive
                </span>
              </li>
              <li className="flex gap-3">
                <span className="text-red-400 font-bold">•</span>
                <span>
                  <strong>Lack of Explainability:</strong> Existing AI systems don't explain <em>why</em> they flagged
                  anomalies, limiting trust
                </span>
              </li>
              <li className="flex gap-3">
                <span className="text-red-400 font-bold">•</span>
                <span>
                  <strong>Disconnected Workflows:</strong> No unified platform connecting image capture, analysis, and
                  field action
                </span>
              </li>
              <li className="flex gap-3">
                <span className="text-red-400 font-bold">•</span>
                <span>
                  <strong>Compliance Risk:</strong> Inconsistent documentation and traceability for regulated industries
                </span>
              </li>
            </ul>
          </Card>

          {/* Solution */}
          <Card className="bg-gradient-to-br from-blue-900/50 to-cyan-900/50 border-blue-700/50 p-8">
            <div className="flex items-start gap-4 mb-6">
              <CheckCircle2 className="w-8 h-8 text-green-400 flex-shrink-0 mt-1" />
              <h3 className="text-2xl font-bold text-white">Our Solution</h3>
            </div>

            <ul className="space-y-4 text-slate-200">
              <li className="flex gap-3">
                <span className="text-green-400 font-bold">✓</span>
                <span>
                  <strong>Automated AI Analysis:</strong> Siamese networks detect pixel-level and semantic changes in
                  seconds
                </span>
              </li>
              <li className="flex gap-3">
                <span className="text-green-400 font-bold">✓</span>
                <span>
                  <strong>Cloud-Native Scalability:</strong> Serverless architecture processes unlimited image streams
                  in parallel
                </span>
              </li>
              <li className="flex gap-3">
                <span className="text-green-400 font-bold">✓</span>
                <span>
                  <strong>Explainable AI:</strong> Attention maps and heatmaps show exactly what changed and why
                </span>
              </li>
              <li className="flex gap-3">
                <span className="text-green-400 font-bold">✓</span>
                <span>
                  <strong>Unified Platform:</strong> Capture → Analyze → Visualize → Act in one integrated dashboard
                </span>
              </li>
              <li className="flex gap-3">
                <span className="text-green-400 font-bold">✓</span>
                <span>
                  <strong>Audit-Ready:</strong> Complete traceability, timestamped reports, and compliance-ready exports
                </span>
              </li>
            </ul>
          </Card>
        </div>
      </div>
    </section>
  )
}
