"use client"

import { Brain, TrendingUp, AlertCircle } from "lucide-react"

export function ExplainabilitySection() {
  return (
    <section className="py-20 px-4 bg-slate-900/50">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">Explainable AI</h2>
          <p className="text-lg text-slate-300 max-w-2xl mx-auto">
            Understand why the AI made each decision. Full transparency for enterprise compliance and trust.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mb-12">
          <div className="bg-slate-900/50 border border-slate-800 rounded-lg p-8">
            <div className="mb-4 inline-block p-3 bg-blue-500/10 rounded-lg">
              <Brain className="w-6 h-6 text-blue-400" />
            </div>
            <h3 className="text-xl font-bold text-white mb-3">Model Interpretability</h3>
            <p className="text-slate-400 mb-4">
              Attention maps and feature visualizations show exactly which image regions influenced each detection.
            </p>
            <ul className="space-y-2 text-sm text-slate-400">
              <li>✓ Grad-CAM visualizations</li>
              <li>✓ Feature importance scores</li>
              <li>✓ Decision trees for each prediction</li>
            </ul>
          </div>

          <div className="bg-slate-900/50 border border-slate-800 rounded-lg p-8">
            <div className="mb-4 inline-block p-3 bg-cyan-500/10 rounded-lg">
              <TrendingUp className="w-6 h-6 text-cyan-400" />
            </div>
            <h3 className="text-xl font-bold text-white mb-3">Performance Metrics</h3>
            <p className="text-slate-400 mb-4">
              Detailed accuracy, precision, recall, and F1 scores for each detection class and confidence threshold.
            </p>
            <ul className="space-y-2 text-sm text-slate-400">
              <li>✓ Per-class metrics</li>
              <li>✓ Confusion matrices</li>
              <li>✓ ROC curves & AUC</li>
            </ul>
          </div>

          <div className="bg-slate-900/50 border border-slate-800 rounded-lg p-8">
            <div className="mb-4 inline-block p-3 bg-purple-500/10 rounded-lg">
              <AlertCircle className="w-6 h-6 text-purple-400" />
            </div>
            <h3 className="text-xl font-bold text-white mb-3">Audit Trail</h3>
            <p className="text-slate-400 mb-4">
              Complete logging of all predictions with timestamps, model versions, and confidence scores for compliance.
            </p>
            <ul className="space-y-2 text-sm text-slate-400">
              <li>✓ Full prediction history</li>
              <li>✓ Model version tracking</li>
              <li>✓ Compliance reports</li>
            </ul>
          </div>
        </div>

        <div className="bg-gradient-to-r from-blue-900/20 to-cyan-900/20 border border-blue-500/20 rounded-lg p-8">
          <h3 className="text-2xl font-bold text-white mb-4">Why Explainability Matters</h3>
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <p className="text-slate-300 mb-3">
                <strong>Regulatory Compliance:</strong> Meet GDPR, HIPAA, and industry-specific requirements for AI
                transparency.
              </p>
            </div>
            <div>
              <p className="text-slate-300 mb-3">
                <strong>Operator Trust:</strong> Empower your team to understand and validate AI decisions in real-time.
              </p>
            </div>
            <div>
              <p className="text-slate-300 mb-3">
                <strong>Continuous Improvement:</strong> Identify model weaknesses and improve training data
                systematically.
              </p>
            </div>
            <div>
              <p className="text-slate-300 mb-3">
                <strong>Risk Mitigation:</strong> Detect and prevent false positives before they impact operations.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
