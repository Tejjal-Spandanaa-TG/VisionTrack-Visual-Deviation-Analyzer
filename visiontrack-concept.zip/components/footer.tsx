"use client"

import { Button } from "@/components/ui/button"
import { Mail, Github, Linkedin } from "lucide-react"

export function Footer() {
  return (
    <footer className="bg-slate-950 border-t border-slate-800 py-12 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="grid md:grid-cols-3 gap-8 mb-8">
          <div>
            <h3 className="text-white font-bold mb-4">VisionTrack</h3>
            <p className="text-sm text-slate-400">AI-powered visual deviation analyzer for the modern enterprise</p>
          </div>
          <div>
            <h4 className="text-white font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2 text-sm text-slate-400">
              <li>
                <a href="#" className="hover:text-blue-400 transition">
                  Problem & Solution
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-blue-400 transition">
                  Technical Architecture
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-blue-400 transition">
                  Use Cases
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-blue-400 transition">
                  Roadmap
                </a>
              </li>
            </ul>
          </div>
          <div>
            <h4 className="text-white font-semibold mb-4">Connect</h4>
            <div className="flex gap-3">
              <Button
                size="sm"
                variant="outline"
                className="border-slate-600 text-slate-300 hover:bg-slate-800 bg-transparent"
              >
                <Mail className="w-4 h-4" />
              </Button>
              <Button
                size="sm"
                variant="outline"
                className="border-slate-600 text-slate-300 hover:bg-slate-800 bg-transparent"
              >
                <Github className="w-4 h-4" />
              </Button>
              <Button
                size="sm"
                variant="outline"
                className="border-slate-600 text-slate-300 hover:bg-slate-800 bg-transparent"
              >
                <Linkedin className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>

        <div className="border-t border-slate-800 pt-8 text-center text-sm text-slate-500">
          <p>VisionTrack © 2025 | Submission-Ready Concept for Visual Difference Engine Challenge</p>
        </div>
      </div>
    </footer>
  )
}
