"use client"

import { Smartphone, Layers, Eye } from "lucide-react"

export function ArVisualization() {
  return (
    <section className="py-20 px-4 bg-slate-900/50">
      <div className="max-w-6xl mx-auto">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">AR-Powered Visualization</h2>
            <p className="text-lg text-slate-300 mb-6">
              Overlay AI analysis directly onto your inspection workflow. See deviations in real-time through your
              mobile device or AR glasses.
            </p>

            <div className="space-y-4">
              <div className="flex gap-4">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-10 w-10 rounded-lg bg-blue-500/20">
                    <Eye className="h-6 w-6 text-blue-400" />
                  </div>
                </div>
                <div>
                  <h3 className="text-white font-semibold mb-1">Live Detection Overlay</h3>
                  <p className="text-slate-400 text-sm">Real-time bounding boxes and heatmaps on live camera feed</p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-10 w-10 rounded-lg bg-cyan-500/20">
                    <Layers className="h-6 w-6 text-cyan-400" />
                  </div>
                </div>
                <div>
                  <h3 className="text-white font-semibold mb-1">Multi-Layer Analysis</h3>
                  <p className="text-slate-400 text-sm">
                    Toggle between different detection models and confidence levels
                  </p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-10 w-10 rounded-lg bg-purple-500/20">
                    <Smartphone className="h-6 w-6 text-purple-400" />
                  </div>
                </div>
                <div>
                  <h3 className="text-white font-semibold mb-1">Mobile & Wearable Ready</h3>
                  <p className="text-slate-400 text-sm">Works on iOS, Android, and enterprise AR devices</p>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-br from-blue-900/30 to-slate-900 rounded-lg border border-slate-700 p-8 aspect-square flex items-center justify-center">
            <div className="text-center">
              <div className="text-7xl mb-4">📱</div>
              <p className="text-slate-300 font-medium">AR Visualization Demo</p>
              <p className="text-sm text-slate-500 mt-2">Interactive AR experience coming soon</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
