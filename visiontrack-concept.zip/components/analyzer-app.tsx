"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Loader2, Upload, X, AlertCircle, CheckCircle2, Zap } from "lucide-react"
import Image from "next/image"

interface AnalysisResult {
  deviations: string[]
  confidence: number
  severity: "low" | "medium" | "high"
  details: string
  anomalies: Array<{
    type: string
    location: string
    confidence: number
  }>
}

export function AnalyzerApp() {
  const [image, setImage] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const [analysis, setAnalysis] = useState<AnalysisResult | null>(null)
  const [error, setError] = useState<string | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    if (!file.type.startsWith("image/")) {
      setError("Please upload an image file")
      return
    }

    if (file.size > 5 * 1024 * 1024) {
      setError("Image must be less than 5MB")
      return
    }

    const reader = new FileReader()
    reader.onload = (event) => {
      setImage(event.target?.result as string)
      setError(null)
      setAnalysis(null)
    }
    reader.readAsDataURL(file)
  }

  const analyzeImage = async () => {
    if (!image) return

    setLoading(true)
    setError(null)

    try {
      const response = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ image }),
      })

      if (!response.ok) {
        throw new Error("Analysis failed")
      }

      const data = await response.json()
      setAnalysis(data)
    } catch (err) {
      setError(err instanceof Error ? err.message : "Analysis failed")
    } finally {
      setLoading(false)
    }
  }

  const clearImage = () => {
    setImage(null)
    setAnalysis(null)
    setError(null)
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-4xl sm:text-5xl font-bold text-white mb-4">AI Visual Analyzer</h2>
          <p className="text-xl text-slate-300">
            Upload an image and let our AI detect visual deviations and anomalies
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Upload Section */}
          <Card className="bg-slate-800/50 border-slate-700 p-8 flex flex-col justify-center">
            <div className="space-y-6">
              <div
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-slate-600 rounded-lg p-12 text-center cursor-pointer hover:border-cyan-400 hover:bg-slate-700/30 transition-all duration-300"
              >
                <Upload className="w-12 h-12 text-cyan-400 mx-auto mb-4" />
                <p className="text-white font-semibold mb-2">Click to upload image</p>
                <p className="text-slate-400 text-sm">or drag and drop</p>
                <p className="text-slate-500 text-xs mt-2">PNG, JPG, GIF up to 5MB</p>
              </div>

              <input ref={fileInputRef} type="file" accept="image/*" onChange={handleImageUpload} className="hidden" />

              {image && (
                <div className="relative w-full aspect-square rounded-lg overflow-hidden bg-slate-900 border border-slate-700">
                  <Image src={image || "/placeholder.svg"} alt="Uploaded" fill className="object-contain" />
                  <button
                    onClick={clearImage}
                    className="absolute top-2 right-2 bg-red-500/80 hover:bg-red-600 text-white p-2 rounded-full transition-colors"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              )}

              {error && (
                <div className="bg-red-500/10 border border-red-500/50 rounded-lg p-4 flex items-start gap-3">
                  <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
                  <p className="text-red-300 text-sm">{error}</p>
                </div>
              )}

              <Button
                onClick={analyzeImage}
                disabled={!image || loading}
                className="w-full bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 text-white font-semibold py-6 rounded-lg transition-all duration-300 disabled:opacity-50"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  <>
                    <Zap className="w-4 h-4 mr-2" />
                    Analyze Image
                  </>
                )}
              </Button>
            </div>
          </Card>

          {/* Results Section */}
          <Card className="bg-slate-800/50 border-slate-700 p-8">
            {!analysis && !loading && (
              <div className="h-full flex items-center justify-center text-center">
                <div>
                  <div className="w-16 h-16 bg-slate-700 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Zap className="w-8 h-8 text-slate-500" />
                  </div>
                  <p className="text-slate-400">Upload and analyze an image to see results</p>
                </div>
              </div>
            )}

            {loading && (
              <div className="h-full flex items-center justify-center">
                <div className="text-center">
                  <Loader2 className="w-12 h-12 text-cyan-400 animate-spin mx-auto mb-4" />
                  <p className="text-white font-semibold">Analyzing image...</p>
                  <p className="text-slate-400 text-sm mt-2">This may take a few seconds</p>
                </div>
              </div>
            )}

            {analysis && (
              <div className="space-y-6">
                {/* Severity Badge */}
                <div className="flex items-center gap-3">
                  {analysis.severity === "high" ? (
                    <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse" />
                  ) : analysis.severity === "medium" ? (
                    <div className="w-3 h-3 bg-yellow-500 rounded-full animate-pulse" />
                  ) : (
                    <div className="w-3 h-3 bg-green-500 rounded-full" />
                  )}
                  <span className="text-white font-semibold capitalize">{analysis.severity} Severity</span>
                </div>

                {/* Confidence Score */}
                <div>
                  <p className="text-slate-300 text-sm mb-2">Confidence Score</p>
                  <div className="w-full bg-slate-700 rounded-full h-2 overflow-hidden">
                    <div
                      className="bg-gradient-to-r from-cyan-400 to-blue-500 h-full transition-all duration-500"
                      style={{ width: `${analysis.confidence * 100}%` }}
                    />
                  </div>
                  <p className="text-cyan-400 font-semibold mt-2">{(analysis.confidence * 100).toFixed(1)}%</p>
                </div>

                {/* Deviations Found */}
                <div>
                  <p className="text-slate-300 text-sm mb-3 font-semibold">Deviations Detected</p>
                  <div className="space-y-2">
                    {analysis.deviations.length > 0 ? (
                      analysis.deviations.map((deviation, idx) => (
                        <div
                          key={idx}
                          className="flex items-start gap-3 bg-slate-700/50 p-3 rounded-lg border border-slate-600"
                        >
                          <AlertCircle className="w-4 h-4 text-yellow-400 flex-shrink-0 mt-0.5" />
                          <p className="text-slate-200 text-sm">{deviation}</p>
                        </div>
                      ))
                    ) : (
                      <div className="flex items-start gap-3 bg-green-500/10 p-3 rounded-lg border border-green-500/30">
                        <CheckCircle2 className="w-4 h-4 text-green-400 flex-shrink-0 mt-0.5" />
                        <p className="text-green-300 text-sm">No significant deviations detected</p>
                      </div>
                    )}
                  </div>
                </div>

                {/* Anomalies */}
                {analysis.anomalies.length > 0 && (
                  <div>
                    <p className="text-slate-300 text-sm mb-3 font-semibold">Anomalies</p>
                    <div className="space-y-2">
                      {analysis.anomalies.map((anomaly, idx) => (
                        <div key={idx} className="bg-slate-700/50 p-3 rounded-lg border border-slate-600">
                          <div className="flex justify-between items-start mb-1">
                            <p className="text-slate-200 font-medium text-sm">{anomaly.type}</p>
                            <span className="text-cyan-400 text-xs font-semibold">
                              {(anomaly.confidence * 100).toFixed(0)}%
                            </span>
                          </div>
                          <p className="text-slate-400 text-xs">{anomaly.location}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Details */}
                <div className="bg-slate-700/30 p-4 rounded-lg border border-slate-600">
                  <p className="text-slate-300 text-sm">{analysis.details}</p>
                </div>

                <Button
                  onClick={clearImage}
                  variant="outline"
                  className="w-full border-slate-600 text-slate-300 hover:bg-slate-700 bg-transparent"
                >
                  Analyze Another Image
                </Button>
              </div>
            )}
          </Card>
        </div>
      </div>
    </section>
  )
}
