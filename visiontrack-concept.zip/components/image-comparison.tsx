"use client"

import type React from "react"

import { useState } from "react"
import { ChevronLeft, ChevronRight } from "lucide-react"

export function ImageComparison() {
  const [sliderPosition, setSliderPosition] = useState(50)

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const container = e.currentTarget
    const rect = container.getBoundingClientRect()
    const x = e.clientX - rect.left
    const percentage = (x / rect.width) * 100
    setSliderPosition(Math.max(0, Math.min(100, percentage)))
  }

  return (
    <section id="demo" className="py-20 px-4 bg-slate-900/50">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">See the Difference</h2>
          <p className="text-lg text-slate-300 max-w-2xl mx-auto">
            Drag the slider to compare original and AI-analyzed images. Watch as our CNN-powered detection highlights
            subtle visual deviations.
          </p>
        </div>

        <div
          className="relative w-full max-w-4xl mx-auto overflow-hidden rounded-lg border border-slate-700 bg-slate-950 aspect-video cursor-col-resize"
          onMouseMove={handleMouseMove}
          onMouseLeave={() => setSliderPosition(50)}
        >
          {/* Before Image */}
          <div className="absolute inset-0 bg-gradient-to-br from-blue-900/20 to-slate-900 flex items-center justify-center">
            <div className="text-center">
              <div className="text-6xl mb-4">📷</div>
              <p className="text-slate-300 font-medium">Original Image</p>
            </div>
          </div>

          {/* After Image with Highlights */}
          <div
            className="absolute inset-0 bg-gradient-to-br from-cyan-900/30 to-blue-900/20 flex items-center justify-center"
            style={{ clipPath: `inset(0 ${100 - sliderPosition}% 0 0)` }}
          >
            <div className="text-center">
              <div className="text-6xl mb-4">🎯</div>
              <p className="text-cyan-300 font-medium">AI Analysis</p>
            </div>
          </div>

          {/* Slider Handle */}
          <div
            className="absolute top-0 bottom-0 w-1 bg-gradient-to-b from-blue-400 to-cyan-400 transition-none"
            style={{ left: `${sliderPosition}%` }}
          >
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-white rounded-full p-2 shadow-lg">
              <div className="flex gap-1">
                <ChevronLeft className="w-4 h-4 text-slate-900" />
                <ChevronRight className="w-4 h-4 text-slate-900" />
              </div>
            </div>
          </div>

          {/* Labels */}
          <div className="absolute top-4 left-4 text-sm font-semibold text-slate-300 pointer-events-none">Original</div>
          <div className="absolute top-4 right-4 text-sm font-semibold text-cyan-300 pointer-events-none">Analyzed</div>
        </div>

        <div className="mt-12 grid md:grid-cols-3 gap-6">
          <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-6">
            <div className="text-3xl mb-3">⚡</div>
            <h3 className="text-white font-semibold mb-2">Real-Time Detection</h3>
            <p className="text-sm text-slate-400">Process images in milliseconds with GPU acceleration</p>
          </div>
          <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-6">
            <div className="text-3xl mb-3">🎯</div>
            <h3 className="text-white font-semibold mb-2">Pixel-Perfect Accuracy</h3>
            <p className="text-sm text-slate-400">Detect deviations as small as 1-2 pixels with confidence scores</p>
          </div>
          <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-6">
            <div className="text-3xl mb-3">📊</div>
            <h3 className="text-white font-semibold mb-2">Detailed Reports</h3>
            <p className="text-sm text-slate-400">Get comprehensive analysis with heatmaps and metrics</p>
          </div>
        </div>
      </div>
    </section>
  )
}
