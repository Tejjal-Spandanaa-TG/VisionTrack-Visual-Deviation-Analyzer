"use client"

import { ArrowRight, Zap } from "lucide-react"
import { Button } from "@/components/ui/button"

export function Hero() {
  const scrollToAnalyzer = () => {
    const element = document.getElementById("analyzer")
    element?.scrollIntoView({ behavior: "smooth" })
  }

  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 px-4 pt-20"
    >
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-20 right-20 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-20 left-20 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl animate-pulse" />
      </div>

      <div className="relative z-10 max-w-4xl mx-auto text-center">
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-cyan-500/10 border border-cyan-500/20 mb-8">
          <Zap className="w-4 h-4 text-cyan-400" />
          <span className="text-sm font-medium text-cyan-300">AI-Powered Visual Analysis</span>
        </div>

        <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 leading-tight">
          VisionTrack
          <span className="block text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-400">
            Visual Deviation Analyzer
          </span>
        </h1>

        <p className="text-xl text-slate-300 mb-8 max-w-2xl mx-auto leading-relaxed">
          Upload any image and let our AI instantly detect visual deviations, anomalies, and quality issues with
          precision and confidence scoring.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button
            size="lg"
            onClick={scrollToAnalyzer}
            className="bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 text-white font-semibold"
          >
            Try Analyzer Now <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
          <Button
            size="lg"
            variant="outline"
            className="border-slate-600 text-slate-200 hover:bg-slate-800 bg-transparent"
          >
            Learn More
          </Button>
        </div>

        <div className="mt-16 grid grid-cols-3 gap-8 text-center">
          <div>
            <div className="text-3xl font-bold text-cyan-400">🤖</div>
            <p className="text-sm text-slate-400 mt-2">AI Detection</p>
          </div>
          <div>
            <div className="text-3xl font-bold text-blue-400">⚡</div>
            <p className="text-sm text-slate-400 mt-2">Real-Time Analysis</p>
          </div>
          <div>
            <div className="text-3xl font-bold text-cyan-400">📊</div>
            <p className="text-sm text-slate-400 mt-2">Confidence Scores</p>
          </div>
        </div>
      </div>
    </section>
  )
}
