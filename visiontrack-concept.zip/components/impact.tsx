"use client"

import { Card } from "@/components/ui/card"
import { TrendingUp, Clock, DollarSign, Shield } from "lucide-react"

export function Impact() {
  const impacts = [
    {
      icon: TrendingUp,
      metric: "95%",
      label: "Defect Detection Accuracy",
      description: "AI-driven precision beats manual inspection",
    },
    {
      icon: Clock,
      metric: "10x",
      label: "Faster Inspection",
      description: "Minutes instead of hours per asset",
    },
    {
      icon: DollarSign,
      metric: "$2M+",
      label: "Annual Savings",
      description: "Reduced labor, downtime, and rework costs",
    },
    {
      icon: Shield,
      metric: "100%",
      label: "Compliance Coverage",
      description: "Audit-ready documentation and traceability",
    },
  ]

  return (
    <section className="py-20 px-4 bg-slate-900">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-4xl font-bold text-white mb-4 text-center">Business Impact</h2>
        <p className="text-slate-400 text-center mb-16 max-w-2xl mx-auto">
          Quantifiable value across efficiency, cost, and compliance
        </p>

        <div className="grid md:grid-cols-4 gap-6">
          {impacts.map((impact, idx) => {
            const Icon = impact.icon
            return (
              <Card
                key={idx}
                className="bg-gradient-to-br from-blue-900/30 to-cyan-900/30 border-blue-700/50 p-6 text-center"
              >
                <Icon className="w-8 h-8 text-blue-400 mx-auto mb-4" />
                <div className="text-3xl font-bold text-white mb-2">{impact.metric}</div>
                <h3 className="text-sm font-semibold text-slate-200 mb-2">{impact.label}</h3>
                <p className="text-xs text-slate-400">{impact.description}</p>
              </Card>
            )
          })}
        </div>

        {/* Key Benefits */}
        <Card className="bg-slate-800 border-slate-700 p-8 mt-12">
          <h3 className="text-2xl font-bold text-white mb-6">Key Benefits</h3>
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h4 className="text-blue-400 font-semibold mb-3">Operational</h4>
              <ul className="text-sm text-slate-300 space-y-2">
                <li>✓ Eliminate manual inspection bottlenecks</li>
                <li>✓ Scale to unlimited assets globally</li>
                <li>✓ Real-time alerts for critical issues</li>
                <li>✓ Predictive maintenance capabilities</li>
              </ul>
            </div>
            <div>
              <h4 className="text-cyan-400 font-semibold mb-3">Strategic</h4>
              <ul className="text-sm text-slate-300 space-y-2">
                <li>✓ Explainable AI builds stakeholder trust</li>
                <li>✓ Compliance-ready audit trails</li>
                <li>✓ Data-driven decision making</li>
                <li>✓ Competitive advantage in regulated markets</li>
              </ul>
            </div>
          </div>
        </Card>
      </div>
    </section>
  )
}
